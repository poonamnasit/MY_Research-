This is a LaTeX template to write a scientific seminar paper at 
[Technische Hochschule Ingolstadt (THI)](www.thi.de)
in the Master's Programme AI Engineering of Autonomous Systems.

The THI logo belongs to [THI](www.thi.de).
